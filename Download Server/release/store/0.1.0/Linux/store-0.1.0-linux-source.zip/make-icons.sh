# 1. Create the directory
mkdir -p build/icons

# 2. Run the loop to create all standard Linux sizes
for size in 16 32 48 64 128 256 512; do
  magick build/icon.png -resize ${size}x${size} build/icons/${size}x${size}.png
done