const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const open = require('open');
const express = require('express');
const unzipper = require('unzipper');

const PORT = 58000;         // Main server (frontend + SSE)
const BACKEND_PORT = 52321; // API / filesystem server
const FRONT_DIR = path.join(__dirname, 'front');
const SESSION_TOKEN = crypto.randomBytes(32).toString('hex');

let server = null;
let backendServer = null;

// SSE clients
let sseClients = [];

// Graceful shutdown
function shutdown() {
    console.log('Shutting down server...');
    setTimeout(() => {
        if (server) server.close(() => console.log('Main server stopped.'));
        if (backendServer) backendServer.close(() => console.log('Backend server stopped.'));
        process.exit(0);
    }, 200);
}

// Start main server (frontend + SSE)
async function startServer() {
    return new Promise((resolve) => {
        const nvxDir = path.join(os.homedir(), 'nvxstdo');
        const appsDir = path.join(nvxDir, 'apps');
        
        if (!fs.existsSync(nvxDir)) fs.mkdirSync(nvxDir, { recursive: true });
        if (!fs.existsSync(appsDir)) fs.mkdirSync(appsDir, { recursive: true });
        
        console.log('Using app directory:', appsDir);
        
        const app = express();
        
        // Serve frontend
        app.use('/', express.static(FRONT_DIR));
        app.use('/apps', express.static(appsDir));
        
        // SSE
        app.get('/events', (req, res) => {
            
            res.writeHead(200, {
                'Content-Type': 'text/event-stream',
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive'
            });
            
            res.write('\n');
            sseClients.push(res);
            
            const heartbeat = setInterval(() => res.write(':\n\n'), 15000);
            
            req.on('close', () => {
                clearInterval(heartbeat);
                sseClients = sseClients.filter(c => c !== res);
            });
        });
        
        // Shutdown
        app.post('/shutdown', express.json(), (req, res) => {
            if (req.body.token !== SESSION_TOKEN) {
                return res.status(403).send('Forbidden');
            }
            res.send('Shutting down...');
            shutdown();
        });
        
        // LOCAL ONLY: 127.0.0.1
        server = app.listen(PORT, '127.0.0.1', () => {
            console.log(`Main server running at http://127.0.0.1:${PORT}`);
            resolve();
        });
    });
}

// Start backend server (filesystem/API)
function startBackendServer() {
    const homedir = path.join(os.homedir(), 'nvxstdo');
    if (!fs.existsSync(homedir)) fs.mkdirSync(homedir, { recursive: true });
    console.log('Using homedir at', homedir);
    
    backendServer = http.createServer(async (req, res) => {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS, GET');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Auth-Token');
        
        if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
        
        if (req.method === 'GET' && req.url === '/userdir') {
            if (req.headers['x-auth-token'] !== SESSION_TOKEN) {
                res.writeHead(403); return res.end('Forbidden');
            }
            res.writeHead(200, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ userDirectory: homedir }));
        }
        
        if (req.method === 'POST' && req.url === '/api/filesystem') {
            let body = '';
            req.on('data', chunk => body += chunk);
            req.on('end', async () => {
                try {
                    const data = JSON.parse(body);
                    const sendJSON = (obj) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
                    const sendError = (err) => sendJSON({ error: err.message || String(err) });
                    
                    const fullPath = (p) => {
                        if (!p) throw new Error('Path argument missing');
                        if (Array.isArray(p)) return path.join(homedir, ...p);
                        if (typeof p === 'string') return path.join(homedir, p);
                        throw new Error('Invalid path type');
                    };
                    
                    switch (data.action) {
                        case 'createDirectory':
                        fs.mkdirSync(fullPath(data.path), { recursive: true });
                        return sendJSON({ success: true });
                        
                        case 'list':
                        return sendJSON({ files: fs.readdirSync(fullPath(data.path)) });
                        
                        case 'readFile':
                        return sendJSON({ content: fs.readFileSync(fullPath(data.path), 'utf8') });
                        
                        case 'write':
                        fs.mkdirSync(path.dirname(fullPath(data.path)), { recursive: true });
                        fs.writeFileSync(fullPath(data.path), data.content);
                        return sendJSON({ success: true });
                        
                        case 'delete': {
                            const target = fullPath(data.path);
                            if (!fs.existsSync(target)) return sendJSON({ success: false, error: 'Not found' });
                            const stat = fs.statSync(target);
                            if (stat.isDirectory()) fs.rmSync(target, { recursive: true, force: true });
                            else fs.unlinkSync(target);
                            return sendJSON({ success: true });
                        }
                        
                        case 'copyFile':
                        const src = fullPath(data.src);
                        const dest = fullPath(data.dest);
                        fs.mkdirSync(path.dirname(dest), { recursive: true }); 
                        fs.copyFileSync(src, dest);
                        return sendJSON({ success: true });
                        
                        case 'pathjoin':
                        if (!Array.isArray(data.path)) throw new Error('Path must be array');
                        return sendJSON({ result: path.join(...data.path) });
                        
                        case 'fileExists':
                        const exists = fs.existsSync(fullPath(data.path));
                        const isDirectory = exists && fs.statSync(fullPath(data.path)).isDirectory();
                        return sendJSON({ exists: String(exists), isDirectory: String(isDirectory) });
                        
                        case 'readNDJSON':
                        if (!fs.existsSync(fullPath(data.path))) return sendJSON([]);
                        const lines = fs.readFileSync(fullPath(data.path), 'utf8')
                        .split("\n").map(l => l.trim()).filter(Boolean)
                        .map(l => { try { return JSON.parse(l); } catch { return null; } })
                        .filter(Boolean);
                        return sendJSON(lines);
                        
                        case 'cache': {
                            if (!data.url) throw new Error('Missing "url" field');
                            const tempDir = path.join(homedir, 'temp');
                            fs.mkdirSync(tempDir, { recursive: true });
                            const urlObj = new URL(data.url);
                            const filename = path.basename(urlObj.pathname) || `cached_${Date.now()}`;
                            const destPath = path.join(tempDir, filename);
                            const proto = urlObj.protocol === 'https:' ? https : http;
                            const file = fs.createWriteStream(destPath);
                            const returnPath = path.join('temp', filename);
                            proto.get(data.url, (response) => {
                                if (response.statusCode == 404) {
                                    fs.unlinkSync(destPath);
                                    return sendError(new Error(`404`));
                                }
                                response.pipe(file);
                                file.on('finish', () => { file.close(); sendJSON({ success: true, path: returnPath }); });
                            }).on('error', (err) => { fs.unlink(destPath, () => {}); sendError(err); });
                            return;
                        }
                        
                        case 'ping': {
                            if (!data.url) throw new Error('Missing "url" field');
                            const urlObj = new URL(data.url);
                            const proto = urlObj.protocol === 'https:' ? https : http;
                            const reqPing = proto.get({
                                method: 'HEAD',
                                host: urlObj.hostname,
                                path: urlObj.pathname || '/',
                                port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
                                timeout: 5000
                            }, (resp) => {
                                sendJSON({ reachable: resp.statusCode < 500 });
                                reqPing.destroy();
                            });
                            reqPing.on('timeout', () => { reqPing.destroy(); sendJSON({ reachable: false }); });
                            reqPing.on('error', () => sendJSON({ reachable: false }));
                            return;
                        }
                        
                        case 'unzip': {
                            if (!data.zipPath || !data.dest) throw new Error('Missing zipPath or dest');
                            const zipFile = fullPath(data.zipPath);
                            const destPath = fullPath(data.dest);
                            if (!fs.existsSync(zipFile)) throw new Error('Zip file not found');
                            await fs.createReadStream(zipFile).pipe(unzipper.Extract({ path: destPath })).promise();
                            return sendJSON({ success: true });
                        }
                        
                        default:
                        res.writeHead(400);
                        return res.end('Invalid action');
                    }
                    
                } catch (err) {
                    console.error(err);
                    res.writeHead(500);
                    res.end('Server error');
                }
            });
            return;
        }
        
        res.writeHead(404);
        res.end('Not Found');
    });
    
    // LOCAL ONLY
    backendServer.listen(BACKEND_PORT, '127.0.0.1', () => {
        console.log(`Backend server running at http://127.0.0.1:${BACKEND_PORT}`);
    });
}

// Main entry
async function main() {
    await startServer();
    startBackendServer();
    await open.default("http://127.0.0.1:58000");
}

main();